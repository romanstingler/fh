package at.fhkaernten;

// 10.1
public interface Clock {
	String getTime();
}
