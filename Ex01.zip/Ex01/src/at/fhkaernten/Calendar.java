package at.fhkaernten;

// 10.2
public interface Calendar extends Clock {
	String getDate();
}
