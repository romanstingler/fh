package at.fhkaernten;

public class Ex0107 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		/**
		 * // 7.1 A class is group of similar objects An object is an abstract
		 * model of a real world object Example: class = Geometric objects
		 * object = rectangle
		 * 
		 * // 7.2 An instance is a specific realization of any object Just use
		 * it
		 * 
		 * // 7.3 'null' is a literal of no type. It is similar to (void *) 0 in
		 * C.
		 * 
		 * // 7.4 this refers to the current object.
		 * 
		 * // 7.5 An instance variable is a variable defined in a class for
		 * which each object of the class has a separate copy, or instance.
		 * 
		 * // 7.6 final keyword is used in several different contexts to define
		 * an entity which cannot later be changed
		 * 
		 * // 7.7 A static member is a member of a class that isn’t associated
		 * with an instance of a class. \nInstead, the member belongs to the
		 * class itself. As a result, you can access the static member without
		 * first creating a class instance.
		 * 
		 * // 7.8 public: The type or member can be accessed by any other code
		 * in the same assembly or another assembly that references it. private:
		 * The type or member can only be accessed by code in the same class or
		 * struct. protected: The type or member can only be accessed by code in
		 * the same class or struct, or in a derived class.
		 * 
		 * // 7.9 The point of getters and setters is that only they are meant
		 * to be used to access the private varialble, which they are getting or
		 * setting.
		 * 
		 * // 7.10 A constructor is a special type of subroutine called to
		 * create an object. A destructor is to delete the object. In Java there
		 * is no need of a destructor due to the garbage collector.
		 * 
		 * // 7.11 Main difference between Constructor and Method is that, you
		 * need to call method explicitly but constructor is called implicitly
		 * by Java programming language during object instantiation.
		 * 
		 * // 7.12 public class HelloWorld{ define class variables public static
		 * void main(String[] args){ }
		 * 
		 * // 7.13 A specific set of instructions to set up and call a given
		 * subroutine, make available the data required by it, and tell the
		 * computer where to return after the subroutine is executed.
		 * 
		 * // 7.14 Use it with the 'dot' operator.
		 **/
	}

}
